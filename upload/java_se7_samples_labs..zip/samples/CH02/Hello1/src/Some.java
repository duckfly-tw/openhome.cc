import cc.openhome.*;
import java.util.*;
public class Some {
    public static void main(String[] args) {
	    cc.openhome.Arrays arrays;
	}
}