/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.openhome;

/**
 *
 * @author Justin
 */
import java.util.*;
public class Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<String> list = Collections.synchronizedList(new java.util.ArrayList<String>());
    }
}
