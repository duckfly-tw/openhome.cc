package cc.openhome;

import java.util.*;
public class Util {
    public static <T> List<T> doSome(T... t) {
        return null;
    }
}
