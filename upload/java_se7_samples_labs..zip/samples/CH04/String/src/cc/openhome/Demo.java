/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.openhome;

import java.util.Arrays;

/**
 *
 * @author Justin
 */
public class Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    }
}
