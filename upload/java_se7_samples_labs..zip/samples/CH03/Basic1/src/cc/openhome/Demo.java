/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.openhome;

/**
 *
 * @author Justin
 */
public class Demo {
    public static void main(String[] args) {
        int x = 10;
        for(;;) {
            System.out.println("XD");
        }
        
        
        
     
        
        
    }
}
