package cc.openhome;

public interface Swimmer {
    public void swim();
}
