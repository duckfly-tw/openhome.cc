package cc.openhome;

public interface Diver extends Swimmer {
    public abstract void dive();
}
