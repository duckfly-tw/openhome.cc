package cc.openhome;

public interface Flyer {
    public abstract void fly();
}
